// module.exports = {
//     MONGODB_URI: process.env.MONGODB_URI,
//     SESSION_SECRET: process.env.SESSION_SECRET,
//     SYSTEM_EMAIL: process.env.SYSTEM_EMAIL,
//     PASSWORD_EMAIL: process.env.PASSWORD_EMAIL
// }

module.exports = {
    BASE_URL: 'localhost',
    MONGODB_URI: 'mongodb+srv://UmarovOtabek:XyXoGfspPY7Rb5a8@cluster0.a0nss.mongodb.net/myFirstDatabase',
    SESSION_SECRET: 'some secret key',
    SYSTEM_EMAIL: 'umarovotabek0220@gmail.com',
    PASSWORD_EMAIL: 'Otabek1999#'
}