// heroku umarovotabek0220@gmail.com Otabek0220#
// mongo umarovotabek0220@gmail.com Otabek0220#

// module.exports = {
//     BASE_URL: 'localhost',
//     MONGODB_URI: 'mongodb://127.0.0.1:27017/gesture',
//     SESSION_SECRET: 'some secret key',
//     SYSTEM_EMAIL: 'umarovotabek0220@gmail.com',
//     PASSWORD_EMAIL: 'Otabek1999#'
// }